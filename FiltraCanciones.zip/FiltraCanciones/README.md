FiltraCanciones

La instalación es simple, descomprime la carpeta y ejecuta la aplicación llamada FiltraCanciones.

El uso es el siguiente:
	- Dentro del cuadro de texto que vemos según iniciamos la aplicación,
	pegaremos una URL (o varias) de una canción que generamos en Spotify, para ello:
		1. Click Derecho
		2. Compartir
		3. Copiar enlace de la canción
		NOTA: También podemos seleccionar más
			+ Todas las canciones: Control + A
			+ Seleccionar canciones en especifico: Control + Click Izquierdo
	- Una vez copiadas las URLs de las canciones, pegaremos en el cuadro de texto las URLs.
	- Pulsaremos sobre el botón 'Procesar URLs', esperaremos un momento, hasta que nos salga 
	la ventana que nos diga:
		+ Proceso completado, Se ha guardado el resultado en resultado.txt
	- Este nuevo 'resultado.txt' se generará en el mismo lugar donde está aplicación (.exe)
	que acabamos de ejecutar.
	- Si quieres reutilizar la aplicación elimina el archivo 'resultado.txt' y voy a realizar el proceso.

Hecho por Víctor Rubio Caballero

Créditos especiales a Víctor Rubio Caballero y ChatGPT-3.5 por su invaluable ayuda y asistencia en el 
desarrollo de este proyecto.

Beta 1

En futuro se añadirán pestañas de idiomas.